import pytest


class TestLogin:

    def test_login_success(self, client):
        resp = client.post("/api/auth/login",
                           json={"username": "alice", "password": "password123"})
        assert resp.status_code == 200
        data = resp.get_json()
        assert data["success"] is True
        assert "access_token"  in data["data"]
        assert "refresh_token" in data["data"]
        assert data["data"]["token_type"] == "Bearer"

    def test_login_wrong_password(self, client):
        resp = client.post("/api/auth/login",
                           json={"username": "alice", "password": "wrong"})
        assert resp.status_code == 401
        assert resp.get_json()["success"] is False

    def test_login_unknown_user(self, client):
        resp = client.post("/api/auth/login",
                           json={"username": "nobody", "password": "x"})
        assert resp.status_code == 401

    def test_login_missing_fields(self, client):
        resp = client.post("/api/auth/login", json={})
        assert resp.status_code == 400

    def test_me_authenticated(self, client, auth_headers):
        resp = client.get("/api/auth/me", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.get_json()["data"]["username"] == "alice"

    def test_me_unauthenticated(self, client):
        resp = client.get("/api/auth/me")
        assert resp.status_code == 401

    def test_refresh_token(self, client):
        login = client.post("/api/auth/login",
                            json={"username": "alice", "password": "password123"})
        refresh_token = login.get_json()["data"]["refresh_token"]

        resp = client.post("/api/auth/refresh",
                           headers={"Authorization": f"Bearer {refresh_token}"})
        assert resp.status_code == 200
        assert "access_token" in resp.get_json()["data"]


class TestAdminRole:

    def test_admin_has_admin_role(self, client):
        resp = client.post("/api/auth/login",
                           json={"username": "admin", "password": "adminPass!"})
        assert resp.status_code == 200
        assert "admin" in resp.get_json()["data"]["roles"]

    def test_alice_has_user_role_only(self, client):
        resp = client.post("/api/auth/login",
                           json={"username": "alice", "password": "password123"})
        roles = resp.get_json()["data"]["roles"]
        assert "user" in roles
        assert "admin" not in roles
