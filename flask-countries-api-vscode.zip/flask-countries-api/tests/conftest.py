import pytest
from app import create_app
from config import TestingConfig


@pytest.fixture
def app():
    app = create_app(TestingConfig)
    yield app


@pytest.fixture
def client(app):
    return app.test_client()


@pytest.fixture
def auth_headers(client):
    """Return JWT Bearer headers for a regular user."""
    resp = client.post("/api/auth/login",
                       json={"username": "alice", "password": "password123"})
    token = resp.get_json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}


@pytest.fixture
def admin_headers(client):
    """Return JWT Bearer headers for an admin user."""
    resp = client.post("/api/auth/login",
                       json={"username": "admin", "password": "adminPass!"})
    token = resp.get_json()["data"]["access_token"]
    return {"Authorization": f"Bearer {token}"}
