import responses as rsps_lib
import pytest


MOCK_COUNTRIES = [
    {
        "name": {"common": "Germany", "official": "Federal Republic of Germany"},
        "cca2": "DE", "cca3": "DEU",
        "region": "Europe", "subregion": "Western Europe",
        "capital": ["Berlin"], "population": 83_000_000,
        "landlocked": False, "borders": ["AT", "FR", "PL"],
        "languages": {"deu": "German"}, "tld": [".de"],
        "flags": {"png": "https://flagcdn.com/de.png", "alt": "German flag"},
    },
    {
        "name": {"common": "France", "official": "French Republic"},
        "cca2": "FR", "cca3": "FRA",
        "region": "Europe", "subregion": "Western Europe",
        "capital": ["Paris"], "population": 67_000_000,
        "landlocked": False, "borders": ["DE", "ES"],
        "languages": {"fra": "French"}, "tld": [".fr"],
        "flags": {"png": "https://flagcdn.com/fr.png", "alt": "French flag"},
    },
]


class TestCountriesProtection:

    def test_no_token_returns_401(self, client):
        resp = client.get("/api/countries")
        assert resp.status_code == 401

    def test_invalid_token_returns_422(self, client):
        resp = client.get("/api/countries",
                          headers={"Authorization": "Bearer badtoken"})
        assert resp.status_code == 422


class TestGetAll:

    @rsps_lib.activate
    def test_get_all_success(self, client, auth_headers):
        rsps_lib.add(rsps_lib.GET,
                     "https://restcountries.com/v3.1/all",
                     json=MOCK_COUNTRIES, status=200)

        resp = client.get("/api/countries?page=0&size=10", headers=auth_headers)
        assert resp.status_code == 200
        body = resp.get_json()
        assert body["success"] is True
        assert len(body["data"]) == 2
        assert body["data"][0]["common_name"] == "Germany"

    @rsps_lib.activate
    def test_get_all_invalid_size(self, client, auth_headers):
        resp = client.get("/api/countries?size=999", headers=auth_headers)
        assert resp.status_code == 400


class TestGetByCode:

    @rsps_lib.activate
    def test_get_by_code_success(self, client, auth_headers):
        rsps_lib.add(rsps_lib.GET,
                     "https://restcountries.com/v3.1/alpha/DE",
                     json=[MOCK_COUNTRIES[0]], status=200)

        resp = client.get("/api/countries/code/DE", headers=auth_headers)
        assert resp.status_code == 200
        assert resp.get_json()["data"]["cca2"] == "DE"

    @rsps_lib.activate
    def test_get_by_code_not_found(self, client, auth_headers):
        rsps_lib.add(rsps_lib.GET,
                     "https://restcountries.com/v3.1/alpha/ZZZ",
                     json={"status": 404, "message": "Not Found"}, status=404)

        resp = client.get("/api/countries/code/ZZZ", headers=auth_headers)
        assert resp.status_code == 404


class TestGetByRegion:

    @rsps_lib.activate
    def test_get_by_region_success(self, client, auth_headers):
        rsps_lib.add(rsps_lib.GET,
                     "https://restcountries.com/v3.1/region/Europe",
                     json=MOCK_COUNTRIES, status=200)

        resp = client.get("/api/countries/region/Europe", headers=auth_headers)
        assert resp.status_code == 200
        assert len(resp.get_json()["data"]) == 2


class TestStats:

    def test_stats_requires_admin(self, client, auth_headers):
        """Regular user should be forbidden."""
        resp = client.get("/api/countries/stats", headers=auth_headers)
        assert resp.status_code == 403

    @rsps_lib.activate
    def test_stats_admin_success(self, client, admin_headers):
        rsps_lib.add(rsps_lib.GET,
                     "https://restcountries.com/v3.1/all",
                     json=MOCK_COUNTRIES, status=200)

        resp = client.get("/api/countries/stats", headers=admin_headers)
        assert resp.status_code == 200
        data = resp.get_json()["data"]
        assert "world_population" in data
        assert data["total_countries"] == 2
        assert data["most_populated_country"] == "Germany"
