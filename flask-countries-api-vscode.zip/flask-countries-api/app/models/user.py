import hashlib
import hmac
import os
from dataclasses import dataclass, field
from typing import Optional


@dataclass
class User:
    username: str
    password_hash: str
    roles: list[str] = field(default_factory=lambda: ["user"])

    def check_password(self, password: str) -> bool:
        """Constant-time password comparison using PBKDF2."""
        expected = _hash_password(password, self.password_hash.split(":")[0])
        return hmac.compare_digest(self.password_hash, expected)

    def to_dict(self) -> dict:
        return {"username": self.username, "roles": self.roles}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _hash_password(password: str, salt: Optional[str] = None) -> str:
    salt = salt or os.urandom(16).hex()
    key  = hashlib.pbkdf2_hmac("sha256", password.encode(), salt.encode(), 260_000)
    return f"{salt}:{key.hex()}"


# ── In-memory user store (replace with DB in production) ──────────────────────

_USERS: dict[str, User] = {
    "alice": User(
        username="alice",
        password_hash=_hash_password("password123"),
        roles=["user"],
    ),
    "admin": User(
        username="admin",
        password_hash=_hash_password("adminPass!"),
        roles=["user", "admin"],
    ),
}


def find_user(username: str) -> Optional[User]:
    return _USERS.get(username)


def get_all_users() -> list[dict]:
    return [u.to_dict() for u in _USERS.values()]
