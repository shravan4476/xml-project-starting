from flask import Blueprint, request
from flask_jwt_extended import jwt_required
from app import cache, limiter
from app.middleware.roles import require_role
from app.services.countries_service import (
    countries_service,
    serialize_country,
    CountryNotFoundError,
    ExternalServiceError,
)
from app.utils.responses import success, error

countries_bp = Blueprint("countries", __name__)


def _handle_service_call(fn, *args, **kwargs):
    """Shared try/except for all service calls."""
    try:
        return fn(*args, **kwargs)
    except CountryNotFoundError as exc:
        return error(str(exc), 404)
    except ExternalServiceError as exc:
        return error(str(exc), 502)


# ── GET /api/countries ─────────────────────────────────────────────────────────

@countries_bp.get("")
@jwt_required()
@limiter.limit("30 per minute")
@cache.cached(timeout=300, query_string=True)
def get_all():
    """
    List all countries with optional pagination.
    Query params: ?page=0&size=20
    """
    try:
        page = int(request.args.get("page", 0))
        size = int(request.args.get("size", 20))
    except ValueError:
        return error("page and size must be integers", 400)

    if size < 1 or size > 100:
        return error("size must be between 1 and 100", 400)

    def fetch():
        all_data = countries_service.get_all()
        serialized = [serialize_country(c) for c in all_data]
        total  = len(serialized)
        start  = page * size
        end    = min(start + size, total)
        return success(
            serialized[start:end],
            message=f"Showing {start + 1}–{end} of {total} countries",
        )

    return _handle_service_call(fetch)


# ── GET /api/countries/name/<name> ─────────────────────────────────────────────

@countries_bp.get("/name/<string:name>")
@jwt_required()
@cache.cached(timeout=300)
def get_by_name(name: str):
    """Search countries by common or official name."""
    def fetch():
        results = countries_service.get_by_name(name)
        return success([serialize_country(c) for c in results])

    return _handle_service_call(fetch)


# ── GET /api/countries/code/<code> ─────────────────────────────────────────────

@countries_bp.get("/code/<string:code>")
@jwt_required()
@cache.cached(timeout=300)
def get_by_code(code: str):
    """Fetch a single country by its ISO alpha-2 or alpha-3 code."""
    def fetch():
        country = countries_service.get_by_code(code.upper())
        return success(serialize_country(country))

    return _handle_service_call(fetch)


# ── GET /api/countries/region/<region> ────────────────────────────────────────

@countries_bp.get("/region/<string:region>")
@jwt_required()
@cache.cached(timeout=300)
def get_by_region(region: str):
    """List all countries in a geographic region (e.g. Europe, Asia)."""
    def fetch():
        results = countries_service.get_by_region(region)
        serialized = [serialize_country(c) for c in results]
        return success(serialized,
                       message=f"{len(serialized)} countries in {region.title()}")

    return _handle_service_call(fetch)


# ── GET /api/countries/language/<language> ────────────────────────────────────

@countries_bp.get("/language/<string:language>")
@jwt_required()
@cache.cached(timeout=300)
def get_by_language(language: str):
    """List all countries that use a given language."""
    def fetch():
        results = countries_service.get_by_language(language)
        serialized = [serialize_country(c) for c in results]
        return success(serialized,
                       message=f"{len(serialized)} countries speak {language.title()}")

    return _handle_service_call(fetch)


# ── GET /api/countries/stats ── ADMIN ONLY ─────────────────────────────────────

@countries_bp.get("/stats")
@jwt_required()
@require_role("admin")
@cache.cached(timeout=600)
def get_stats():
    """
    Population statistics across all countries.
    Requires ADMIN role.
    """
    def fetch():
        stats = countries_service.get_population_stats()
        return success(stats)

    return _handle_service_call(fetch)
