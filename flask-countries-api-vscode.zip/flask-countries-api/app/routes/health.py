from flask import Blueprint, jsonify
import requests
from flask import current_app

health_bp = Blueprint("health", __name__)


@health_bp.get("/health")
def health():
    """Public health check — no auth required."""
    # Ping external API (lightweight /all?fields=cca2 call)
    ext_status = "ok"
    try:
        base = current_app.config["COUNTRIES_API_BASE_URL"]
        r = requests.get(f"{base}/all?fields=cca2",
                         timeout=3)
        if not r.ok:
            ext_status = f"degraded (HTTP {r.status_code})"
    except Exception as exc:
        ext_status = f"unreachable ({exc})"

    return jsonify({
        "status": "ok",
        "service": "flask-countries-api",
        "external_api": {
            "name":   "REST Countries v3.1",
            "status": ext_status,
        },
    }), 200
