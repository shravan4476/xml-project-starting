from flask import Blueprint, request
from flask_jwt_extended import (
    create_access_token,
    create_refresh_token,
    jwt_required,
    get_jwt_identity,
    get_jwt,
)

from app.models.user import find_user
from app.utils.responses import success, error
from app import limiter

auth_bp = Blueprint("auth", __name__)


# ── POST /api/auth/login ───────────────────────────────────────────────────────

@auth_bp.post("/login")
@limiter.limit("10 per minute")
def login():
    """
    Authenticate with username + password.
    Returns a short-lived access token and a long-lived refresh token.
    """
    body = request.get_json(silent=True) or {}
    username = body.get("username", "").strip()
    password = body.get("password", "")

    if not username or not password:
        return error("username and password are required", 400)

    user = find_user(username)
    if not user or not user.check_password(password):
        return error("Invalid username or password", 401)

    additional_claims = {"roles": user.roles}
    access_token  = create_access_token(identity=username,
                                        additional_claims=additional_claims)
    refresh_token = create_refresh_token(identity=username,
                                         additional_claims=additional_claims)

    return success({
        "access_token":  access_token,
        "refresh_token": refresh_token,
        "token_type":    "Bearer",
        "username":      username,
        "roles":         user.roles,
    }, message="Login successful")


# ── POST /api/auth/refresh ─────────────────────────────────────────────────────

@auth_bp.post("/refresh")
@jwt_required(refresh=True)
def refresh():
    """
    Exchange a valid refresh token for a new access token.
    Send refresh token in the Authorization: Bearer <token> header.
    """
    identity = get_jwt_identity()
    claims   = get_jwt()
    roles    = claims.get("roles", [])

    new_access = create_access_token(
        identity=identity,
        additional_claims={"roles": roles},
    )
    return success({"access_token": new_access, "token_type": "Bearer"},
                   message="Token refreshed")


# ── GET /api/auth/me ───────────────────────────────────────────────────────────

@auth_bp.get("/me")
@jwt_required()
def me():
    """Return the currently authenticated user's profile."""
    username = get_jwt_identity()
    user     = find_user(username)
    if not user:
        return error("User not found", 404)
    return success(user.to_dict())
