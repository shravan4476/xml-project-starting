from flask import Flask, jsonify
from flask_jwt_extended import JWTManager
from flask_caching import Cache
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

from config import get_config

# ── Extension instances (initialised in create_app) ───────────────────────────
jwt     = JWTManager()
cache   = Cache()
limiter = Limiter(key_func=get_remote_address)


def create_app(config_class=None):
    app = Flask(__name__)

    # Load config
    app.config.from_object(config_class or get_config())

    # ── Initialise extensions ──────────────────────────────────────────────────
    jwt.init_app(app)
    cache.init_app(app)
    limiter.init_app(app)

    # ── JWT error handlers ─────────────────────────────────────────────────────
    _register_jwt_handlers(jwt)

    # ── Blueprints ─────────────────────────────────────────────────────────────
    from app.routes.auth      import auth_bp
    from app.routes.countries import countries_bp
    from app.routes.health    import health_bp

    app.register_blueprint(auth_bp,      url_prefix="/api/auth")
    app.register_blueprint(countries_bp, url_prefix="/api/countries")
    app.register_blueprint(health_bp,    url_prefix="/api")

    # ── Generic 404 / 405 ─────────────────────────────────────────────────────
    @app.errorhandler(404)
    def not_found(_):
        return jsonify({"success": False, "error": "Endpoint not found"}), 404

    @app.errorhandler(405)
    def method_not_allowed(_):
        return jsonify({"success": False, "error": "Method not allowed"}), 405

    @app.errorhandler(429)
    def rate_limit_exceeded(e):
        return jsonify({"success": False, "error": f"Rate limit exceeded: {e.description}"}), 429

    return app


def _register_jwt_handlers(jwt_manager: JWTManager):
    """Map JWT errors to consistent JSON responses."""

    @jwt_manager.unauthorized_loader
    def missing_token(reason):
        return jsonify({"success": False, "error": f"Missing token: {reason}"}), 401

    @jwt_manager.invalid_token_loader
    def invalid_token(reason):
        return jsonify({"success": False, "error": f"Invalid token: {reason}"}), 422

    @jwt_manager.expired_token_loader
    def expired_token(_header, _payload):
        return jsonify({"success": False, "error": "Token has expired"}), 401

    @jwt_manager.revoked_token_loader
    def revoked_token(_header, _payload):
        return jsonify({"success": False, "error": "Token has been revoked"}), 401
