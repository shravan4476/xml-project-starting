from datetime import datetime, timezone
from flask import jsonify


def success(data, message: str = None, status: int = 200):
    """Return a consistent success envelope."""
    body = {
        "success": True,
        "data": data,
        "timestamp": _now(),
    }
    if message:
        body["message"] = message
    return jsonify(body), status


def error(message: str, status: int = 400):
    """Return a consistent error envelope."""
    return jsonify({
        "success": False,
        "error": message,
        "timestamp": _now(),
    }), status


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()
