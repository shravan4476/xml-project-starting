import logging
from typing import Any

import requests
from flask import current_app

logger = logging.getLogger(__name__)


class CountryNotFoundError(Exception):
    pass


class ExternalServiceError(Exception):
    pass


class CountriesService:
    """
    Wraps every call to the REST Countries v3.1 API.
    All methods raise CountryNotFoundError or ExternalServiceError —
    never raw requests exceptions — so routes stay clean.
    """

    def _base_url(self) -> str:
        return current_app.config["COUNTRIES_API_BASE_URL"]

    def _timeout(self) -> int:
        return current_app.config["COUNTRIES_API_TIMEOUT"]

    # ── Internal HTTP helper ───────────────────────────────────────────────────

    def _get(self, path: str) -> Any:
        url = f"{self._base_url()}{path}"
        logger.debug("[EXTERNAL] --> GET %s", url)
        try:
            resp = requests.get(url, timeout=self._timeout())
            logger.debug("[EXTERNAL] <-- HTTP %s", resp.status_code)
        except requests.Timeout:
            raise ExternalServiceError("REST Countries API timed out")
        except requests.ConnectionError as exc:
            raise ExternalServiceError(f"Cannot reach REST Countries API: {exc}")

        if resp.status_code == 404:
            return None          # caller decides meaning
        if not resp.ok:
            raise ExternalServiceError(
                f"REST Countries API returned HTTP {resp.status_code}"
            )
        return resp.json()

    # ── Public methods ─────────────────────────────────────────────────────────

    def get_all(self) -> list[dict]:
        data = self._get("/all")
        if not data:
            raise ExternalServiceError("Received empty response for /all")
        return data

    def get_by_name(self, name: str) -> list[dict]:
        data = self._get(f"/name/{name}")
        if data is None:
            raise CountryNotFoundError(f"No country found with name '{name}'")
        return data

    def get_by_code(self, code: str) -> dict:
        data = self._get(f"/alpha/{code}")
        if data is None or (isinstance(data, list) and len(data) == 0):
            raise CountryNotFoundError(f"No country found with code '{code}'")
        return data[0] if isinstance(data, list) else data

    def get_by_region(self, region: str) -> list[dict]:
        data = self._get(f"/region/{region}")
        if data is None:
            raise CountryNotFoundError(f"No countries found in region '{region}'")
        return data

    def get_by_language(self, language: str) -> list[dict]:
        data = self._get(f"/lang/{language}")
        if data is None:
            raise CountryNotFoundError(f"No countries found for language '{language}'")
        return data

    # ── Server-side aggregation ────────────────────────────────────────────────

    def get_population_stats(self) -> dict:
        countries = self.get_all()
        populations = [c.get("population", 0) for c in countries]
        non_zero    = [p for p in populations if p > 0]

        most_pop    = max(countries, key=lambda c: c.get("population", 0))
        least_pop   = min(
            (c for c in countries if c.get("population", 0) > 0),
            key=lambda c: c.get("population", 0),
        )

        return {
            "total_countries":        len(countries),
            "world_population":       sum(populations),
            "average_population":     int(sum(populations) / len(populations)),
            "most_populated_country": _common_name(most_pop),
            "most_populated_value":   most_pop.get("population"),
            "least_populated_country": _common_name(least_pop),
            "least_populated_value":  least_pop.get("population"),
        }


# ── DTO mapper ─────────────────────────────────────────────────────────────────

def serialize_country(raw: dict) -> dict:
    """Map raw REST Countries v3.1 shape to our API's cleaner DTO."""
    name   = raw.get("name", {})
    flags  = raw.get("flags", {})
    return {
        "common_name":    name.get("common"),
        "official_name":  name.get("official"),
        "cca2":           raw.get("cca2"),
        "cca3":           raw.get("cca3"),
        "region":         raw.get("region"),
        "subregion":      raw.get("subregion"),
        "capital":        raw.get("capital"),
        "population":     raw.get("population"),
        "landlocked":     raw.get("landlocked"),
        "borders":        raw.get("borders"),
        "languages":      raw.get("languages"),
        "top_level_domains": raw.get("tld"),
        "flag_url":       flags.get("png"),
        "flag_description": flags.get("alt"),
    }


def _common_name(raw: dict) -> str:
    return raw.get("name", {}).get("common", "Unknown")


# ── Singleton ──────────────────────────────────────────────────────────────────
countries_service = CountriesService()
