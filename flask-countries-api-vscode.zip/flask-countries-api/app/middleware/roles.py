from functools import wraps
from flask import jsonify
from flask_jwt_extended import get_jwt


def require_role(*roles: str):
    """
    Decorator that checks the 'roles' claim in the JWT.
    Must be used AFTER @jwt_required().

    Usage:
        @jwt_required()
        @require_role("admin")
        def admin_only_view(): ...
    """
    def decorator(fn):
        @wraps(fn)
        def wrapper(*args, **kwargs):
            claims      = get_jwt()
            user_roles  = claims.get("roles", [])
            if not any(r in user_roles for r in roles):
                return jsonify({
                    "success": False,
                    "error": "You do not have permission to access this resource",
                }), 403
            return fn(*args, **kwargs)
        return wrapper
    return decorator
