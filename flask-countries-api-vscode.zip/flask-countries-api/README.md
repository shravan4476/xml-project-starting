# 🌍 Flask Countries API

A production-ready, secured REST API built with **Flask** that integrates with the
[REST Countries v3.1](https://restcountries.com) external service.  
Authentication uses **JWT (JSON Web Tokens)** with access + refresh token flow.

---

## Architecture

```
flask-countries-api/
├── run.py                        # Entry point
├── config.py                     # Config classes (dev / test / prod)
├── requirements.txt
├── .env.example
└── app/
    ├── __init__.py               # App factory — registers extensions & blueprints
    ├── middleware/
    │   └── roles.py              # @require_role("admin") decorator
    ├── models/
    │   └── user.py               # In-memory user store + PBKDF2 password hashing
    ├── routes/
    │   ├── auth.py               # /api/auth — login, refresh, /me
    │   ├── countries.py          # /api/countries — all country endpoints
    │   └── health.py             # /api/health — public health check
    ├── services/
    │   └── countries_service.py  # WebClient wrapper for REST Countries API
    └── utils/
        └── responses.py          # success() / error() envelope helpers
```

---

## Quickstart

```bash
# 1. Clone & enter directory
cd flask-countries-api

# 2. Create virtual environment
python3 -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Set environment variables
cp .env.example .env
# Edit .env — at minimum change JWT_SECRET_KEY and SECRET_KEY

# 5. Run the server
python run.py
# Server starts at http://localhost:8080
```

---

## API Reference

All responses share this envelope:
```json
{
  "success": true | false,
  "data":    { ... },       // present on success
  "error":   "...",         // present on failure
  "message": "...",         // optional context
  "timestamp": "2024-..."
}
```

### Auth Endpoints (public)

| Method | Path                  | Description                          |
|--------|-----------------------|--------------------------------------|
| POST   | `/api/auth/login`     | Get access + refresh tokens          |
| POST   | `/api/auth/refresh`   | Refresh access token                 |
| GET    | `/api/auth/me`        | Get current user profile (JWT req.)  |

**Login request:**
```json
{ "username": "alice", "password": "password123" }
```

**Login response:**
```json
{
  "success": true,
  "data": {
    "access_token":  "<JWT>",
    "refresh_token": "<JWT>",
    "token_type":    "Bearer",
    "username":      "alice",
    "roles":         ["user"]
  }
}
```

### Country Endpoints (JWT required)

Include `Authorization: Bearer <access_token>` on all requests.

| Method | Path                               | Auth  | Description                       |
|--------|------------------------------------|-------|-----------------------------------|
| GET    | `/api/countries`                   | user  | All countries (paginated)         |
| GET    | `/api/countries/name/{name}`       | user  | Search by name                    |
| GET    | `/api/countries/code/{code}`       | user  | By ISO alpha-2 or alpha-3 code    |
| GET    | `/api/countries/region/{region}`   | user  | Countries in a region             |
| GET    | `/api/countries/language/{lang}`   | user  | Countries by spoken language      |
| GET    | `/api/countries/stats`             | admin | Population statistics (ADMIN)     |

**Pagination:** `?page=0&size=20` (max size: 100)

**Example — get Germany:**
```bash
curl -H "Authorization: Bearer $TOKEN" \
     http://localhost:8080/api/countries/code/DE
```

**Example — countries in Asia:**
```bash
curl -H "Authorization: Bearer $TOKEN" \
     http://localhost:8080/api/countries/region/Asia
```

### Health Check (public)

```bash
GET /api/health
```
Returns app status and external API reachability.

---

## Default Users

| Username | Password      | Roles        |
|----------|---------------|--------------|
| alice    | password123   | user         |
| admin    | adminPass!    | user, admin  |

> ⚠️ Replace with a real database + bcrypt in production.

---

## Security Features

- **JWT access tokens** (1-hour TTL) + **refresh tokens** (30-day TTL)
- **Role-based access control** via `@require_role()` decorator
- **PBKDF2-SHA256** password hashing (260,000 iterations)
- **Rate limiting** — 10 login attempts/minute, 30 country requests/minute
- **Stateless** — no server-side sessions

---

## Running Tests

```bash
pytest tests/ -v
```

Tests use `responses` library to mock the external REST Countries API —
no real network calls during testing.

---

## Production Deployment

```bash
# With Gunicorn (included in requirements)
gunicorn "app:create_app()" --bind 0.0.0.0:8080 --workers 4

# Key env vars to set in production:
# SECRET_KEY=<random 32+ bytes>
# JWT_SECRET_KEY=<random 32+ bytes>
# FLASK_ENV=production
# CACHE_TYPE=RedisCache  (with CACHE_REDIS_URL)
```
